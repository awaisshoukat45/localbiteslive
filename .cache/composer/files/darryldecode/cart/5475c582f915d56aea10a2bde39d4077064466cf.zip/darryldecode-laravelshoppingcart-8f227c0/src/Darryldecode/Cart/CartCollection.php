<?php namespace Darryldecode\Cart;

use Illuminate\Support\Collection;

class CartCollection extends Collection {

}