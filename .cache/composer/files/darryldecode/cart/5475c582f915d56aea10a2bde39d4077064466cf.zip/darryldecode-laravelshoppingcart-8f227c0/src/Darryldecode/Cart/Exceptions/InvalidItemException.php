<?php namespace Darryldecode\Cart\Exceptions;

/**
 * Created by PhpStorm.
 * User: darryl
 * Date: 1/12/2015
 * Time: 9:40 PM
 */

class InvalidItemException extends \Exception {

}